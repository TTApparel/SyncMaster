<?php

if (!defined('ABSPATH')) {
    exit;
}

function syncmaster_register_admin_menu() {
    add_menu_page(
        __('SyncMaster', 'syncmaster'),
        __('SyncMaster', 'syncmaster'),
        'manage_options',
        'syncmaster_dashboard',
        'syncmaster_render_dashboard',
        'dashicons-update',
        56
    );

    add_submenu_page(
        'syncmaster_dashboard',
        __('Dashboard', 'syncmaster'),
        __('Dashboard', 'syncmaster'),
        'manage_options',
        'syncmaster_dashboard',
        'syncmaster_render_dashboard'
    );

    add_submenu_page(
        'syncmaster_dashboard',
        __('Products', 'syncmaster'),
        __('Products', 'syncmaster'),
        'manage_options',
        'syncmaster_products',
        'syncmaster_render_products'
    );

    add_submenu_page(
        'syncmaster_dashboard',
        __('Sync Logs', 'syncmaster'),
        __('Sync Logs', 'syncmaster'),
        'manage_options',
        'syncmaster_logs',
        'syncmaster_render_logs'
    );

    add_submenu_page(
        'syncmaster_dashboard',
        __('Settings', 'syncmaster'),
        __('Settings', 'syncmaster'),
        'manage_options',
        'syncmaster_settings',
        'syncmaster_render_settings'
    );
}

function syncmaster_render_shell($active = 'dashboard', $content = '') {
    $pages = array(
        'dashboard' => array('label' => __('Dashboard', 'syncmaster'), 'slug' => 'syncmaster_dashboard'),
        'products' => array('label' => __('Products', 'syncmaster'), 'slug' => 'syncmaster_products'),
        'logs' => array('label' => __('Sync Logs', 'syncmaster'), 'slug' => 'syncmaster_logs'),
        'settings' => array('label' => __('Settings', 'syncmaster'), 'slug' => 'syncmaster_settings'),
    );
    ?>
    <div class="wrap syncmaster-admin">
        <div class="syncmaster-header">
            <h1><?php echo esc_html__('SyncMaster', 'syncmaster'); ?></h1>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('syncmaster_sync_now'); ?>
                <input type="hidden" name="action" value="syncmaster_sync_now">
                <button type="submit" class="button button-primary syncmaster-sync-now">
                    <?php echo esc_html__('Sync Now', 'syncmaster'); ?>
                </button>
            </form>
        </div>
        <div class="syncmaster-layout">
            <aside class="syncmaster-sidebar">
                <nav>
                    <ul>
                        <?php foreach ($pages as $key => $page) : ?>
                            <li class="<?php echo $key === $active ? 'active' : ''; ?>">
                                <a href="<?php echo esc_url(admin_url('admin.php?page=' . $page['slug'])); ?>">
                                    <?php echo esc_html($page['label']); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </nav>
            </aside>
            <main class="syncmaster-content">
                <?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </main>
        </div>
    </div>
    <?php
}

function syncmaster_render_dashboard() {
    ob_start();
    ?>
    <section class="syncmaster-card">
        <h2><?php echo esc_html__('Overview', 'syncmaster'); ?></h2>
        <p><?php echo esc_html__('Welcome to SyncMaster. Use the sidebar to manage products, view sync logs, and configure settings.', 'syncmaster'); ?></p>
    </section>
    <div class="syncmaster-grid">
        <section class="syncmaster-card">
            <h3><?php echo esc_html__('Monitored Products', 'syncmaster'); ?></h3>
            <p class="syncmaster-metric"><?php echo esc_html(syncmaster_get_products_count()); ?></p>
        </section>
        <section class="syncmaster-card">
            <h3><?php echo esc_html__('Last Sync', 'syncmaster'); ?></h3>
            <p class="syncmaster-metric"><?php echo esc_html(syncmaster_get_last_sync_time()); ?></p>
        </section>
        <section class="syncmaster-card">
            <h3><?php echo esc_html__('Latest Status', 'syncmaster'); ?></h3>
            <p class="syncmaster-metric"><?php echo esc_html(syncmaster_get_last_sync_status()); ?></p>
        </section>
    </div>
    <?php
    $content = ob_get_clean();
    syncmaster_render_shell('dashboard', $content);
}

function syncmaster_render_products() {
    $query = isset($_GET['ss_query']) ? sanitize_text_field(wp_unslash($_GET['ss_query'])) : '';
    $search_results = array();
    if ($query !== '') {
        $search_results = syncmaster_ss_search($query);
    }
    $monitored = syncmaster_get_monitored_products();

    ob_start();
    ?>
    <section class="syncmaster-card">
        <h2><?php echo esc_html__('Search Products', 'syncmaster'); ?></h2>
        <form method="get" class="syncmaster-search">
            <input type="hidden" name="page" value="syncmaster_products">
            <input type="search" name="ss_query" value="<?php echo esc_attr($query); ?>" placeholder="<?php echo esc_attr__('Search by name or SKU', 'syncmaster'); ?>">
            <button type="submit" class="button"><?php echo esc_html__('Search', 'syncmaster'); ?></button>
        </form>
        <?php if ($query !== '') : ?>
            <div class="syncmaster-search-results">
                <h3><?php echo esc_html__('Search Results', 'syncmaster'); ?></h3>
                <?php if (empty($search_results)) : ?>
                    <p><?php echo esc_html__('No results found.', 'syncmaster'); ?></p>
                <?php else : ?>
                    <ul>
                        <?php foreach ($search_results as $result) : ?>
                            <li class="syncmaster-result">
                                <div>
                                    <strong><?php echo esc_html($result['name']); ?></strong>
                                    <span class="syncmaster-muted"><?php echo esc_html($result['sku']); ?></span>
                                </div>
                                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                    <?php wp_nonce_field('syncmaster_add_sku'); ?>
                                    <input type="hidden" name="action" value="syncmaster_add_sku">
                                    <input type="hidden" name="sku" value="<?php echo esc_attr($result['sku']); ?>">
                                    <button type="submit" class="button button-primary">
                                        <?php echo esc_html__('Add to Monitored', 'syncmaster'); ?>
                                    </button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </section>

    <section class="syncmaster-card">
        <h2><?php echo esc_html__('Monitored Products', 'syncmaster'); ?></h2>
        <?php if (empty($monitored)) : ?>
            <p><?php echo esc_html__('No products monitored yet.', 'syncmaster'); ?></p>
        <?php else : ?>
            <ul class="syncmaster-monitored">
                <?php foreach ($monitored as $item) : ?>
                    <li>
                        <span><?php echo esc_html($item['sku']); ?></span>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                            <?php wp_nonce_field('syncmaster_remove_sku'); ?>
                            <input type="hidden" name="action" value="syncmaster_remove_sku">
                            <input type="hidden" name="sku" value="<?php echo esc_attr($item['sku']); ?>">
                            <button type="submit" class="button button-link-delete syncmaster-remove">
                                <?php echo esc_html__('Remove', 'syncmaster'); ?>
                            </button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </section>
    <?php
    $content = ob_get_clean();
    syncmaster_render_shell('products', $content);
}

function syncmaster_render_logs() {
    $logs = syncmaster_get_logs();

    ob_start();
    ?>
    <section class="syncmaster-card">
        <h2><?php echo esc_html__('Sync Logs', 'syncmaster'); ?></h2>
        <?php if (empty($logs)) : ?>
            <p><?php echo esc_html__('No logs recorded yet.', 'syncmaster'); ?></p>
        <?php else : ?>
            <ul class="syncmaster-logs">
                <?php foreach ($logs as $log) : ?>
                    <li class="syncmaster-log syncmaster-log-<?php echo esc_attr($log['level']); ?>">
                        <div>
                            <strong><?php echo esc_html($log['message']); ?></strong>
                            <div class="syncmaster-muted">
                                <?php echo esc_html($log['log_time']); ?> · <?php echo esc_html(strtoupper($log['level'])); ?>
                            </div>
                        </div>
                        <div class="syncmaster-log-counts">
                            <span><?php echo esc_html(sprintf(__('Success: %d', 'syncmaster'), $log['success_count'])); ?></span>
                            <span><?php echo esc_html(sprintf(__('Fail: %d', 'syncmaster'), $log['fail_count'])); ?></span>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </section>
    <?php
    $content = ob_get_clean();
    syncmaster_render_shell('logs', $content);
}

function syncmaster_render_settings() {
    $options = syncmaster_get_settings();

    ob_start();
    ?>
    <section class="syncmaster-card">
        <h2><?php echo esc_html__('Settings', 'syncmaster'); ?></h2>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="syncmaster-settings">
            <?php wp_nonce_field('syncmaster_save_settings'); ?>
            <input type="hidden" name="action" value="syncmaster_save_settings">

            <div class="syncmaster-field">
                <label for="ss_username"><?php echo esc_html__('SS Username', 'syncmaster'); ?></label>
                <input type="text" id="ss_username" name="ss_username" value="<?php echo esc_attr($options['ss_username']); ?>">
            </div>
            <div class="syncmaster-field">
                <label for="ss_password"><?php echo esc_html__('SS Password', 'syncmaster'); ?></label>
                <input type="password" id="ss_password" name="ss_password" value="<?php echo esc_attr($options['ss_password']); ?>">
            </div>
            <div class="syncmaster-field">
                <label for="wc_url"><?php echo esc_html__('WooCommerce URL', 'syncmaster'); ?></label>
                <input type="url" id="wc_url" name="wc_url" value="<?php echo esc_attr($options['wc_url']); ?>">
            </div>
            <div class="syncmaster-field">
                <label for="wc_ck"><?php echo esc_html__('WooCommerce Consumer Key', 'syncmaster'); ?></label>
                <input type="password" id="wc_ck" name="wc_ck" value="<?php echo esc_attr($options['wc_ck']); ?>">
            </div>
            <div class="syncmaster-field">
                <label for="wc_cs"><?php echo esc_html__('WooCommerce Consumer Secret', 'syncmaster'); ?></label>
                <input type="password" id="wc_cs" name="wc_cs" value="<?php echo esc_attr($options['wc_cs']); ?>">
            </div>
            <div class="syncmaster-field">
                <label for="sync_interval_minutes"><?php echo esc_html__('Sync Interval (minutes)', 'syncmaster'); ?></label>
                <input type="number" id="sync_interval_minutes" name="sync_interval_minutes" min="5" value="<?php echo esc_attr($options['sync_interval_minutes']); ?>">
            </div>
            <button type="submit" class="button button-primary">
                <?php echo esc_html__('Save Settings', 'syncmaster'); ?>
            </button>
        </form>
    </section>
    <?php
    $content = ob_get_clean();
    syncmaster_render_shell('settings', $content);
}
