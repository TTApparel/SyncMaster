<?php

if (!defined('ABSPATH')) {
    exit;
}

function syncmaster_get_settings() {
    return array(
        'ss_username' => get_option('ss_username', ''),
        'ss_password' => get_option('ss_password', ''),
        'wc_url' => get_option('wc_url', ''),
        'wc_ck' => get_option('wc_ck', ''),
        'wc_cs' => get_option('wc_cs', ''),
        'sync_interval_minutes' => (int) get_option('sync_interval_minutes', 60),
    );
}

function syncmaster_handle_save_settings() {
    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'syncmaster'));
    }

    check_admin_referer('syncmaster_save_settings');

    $settings = array(
        'ss_username' => sanitize_text_field(wp_unslash($_POST['ss_username'] ?? '')),
        'ss_password' => sanitize_text_field(wp_unslash($_POST['ss_password'] ?? '')),
        'wc_url' => esc_url_raw(wp_unslash($_POST['wc_url'] ?? '')),
        'wc_ck' => sanitize_text_field(wp_unslash($_POST['wc_ck'] ?? '')),
        'wc_cs' => sanitize_text_field(wp_unslash($_POST['wc_cs'] ?? '')),
        'sync_interval_minutes' => (int) ($_POST['sync_interval_minutes'] ?? 60),
    );

    foreach ($settings as $key => $value) {
        update_option($key, $value);
    }

    syncmaster_reschedule_cron();

    wp_safe_redirect(admin_url('admin.php?page=syncmaster_settings&updated=1'));
    exit;
}

function syncmaster_reschedule_cron() {
    wp_clear_scheduled_hook('syncmaster_cron_sync');
    syncmaster_schedule_cron();
}

function syncmaster_handle_sync_now() {
    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'syncmaster'));
    }

    check_admin_referer('syncmaster_sync_now');

    syncmaster_write_log('info', __('Manual sync triggered.', 'syncmaster'), 0, 0, array('source' => 'manual'));
    syncmaster_run_sync_placeholder();

    wp_safe_redirect(admin_url('admin.php?page=syncmaster_dashboard&synced=1'));
    exit;
}

function syncmaster_run_scheduled_sync() {
    syncmaster_write_log('info', __('Scheduled sync triggered.', 'syncmaster'), 0, 0, array('source' => 'cron'));
    syncmaster_run_sync_placeholder();
}

function syncmaster_run_sync_placeholder() {
    $success = rand(5, 15);
    $fail = rand(0, 3);
    syncmaster_write_log('success', __('Sync completed.', 'syncmaster'), $success, $fail, array('duration' => rand(10, 40)));
}

function syncmaster_write_log($level, $message, $success_count = 0, $fail_count = 0, $context = array()) {
    global $wpdb;
    $table = $wpdb->prefix . SYNCMASTER_LOGS_TABLE;
    $wpdb->insert(
        $table,
        array(
            'log_time' => current_time('mysql'),
            'level' => $level,
            'message' => $message,
            'success_count' => (int) $success_count,
            'fail_count' => (int) $fail_count,
            'context_json' => wp_json_encode($context),
        ),
        array('%s', '%s', '%s', '%d', '%d', '%s')
    );
}

function syncmaster_get_logs() {
    global $wpdb;
    $table = $wpdb->prefix . SYNCMASTER_LOGS_TABLE;
    return $wpdb->get_results("SELECT log_time, level, message, success_count, fail_count FROM {$table} ORDER BY log_time DESC LIMIT 50", ARRAY_A);
}

function syncmaster_get_last_sync_time() {
    $logs = syncmaster_get_logs();
    if (empty($logs)) {
        return __('Never', 'syncmaster');
    }
    return $logs[0]['log_time'];
}

function syncmaster_get_last_sync_status() {
    $logs = syncmaster_get_logs();
    if (empty($logs)) {
        return __('No data', 'syncmaster');
    }
    return ucfirst($logs[0]['level']);
}

function syncmaster_get_monitored_products() {
    global $wpdb;
    $table = $wpdb->prefix . SYNCMASTER_PRODUCTS_TABLE;
    return $wpdb->get_results("SELECT sku FROM {$table} ORDER BY created_at DESC", ARRAY_A);
}

function syncmaster_get_products_count() {
    global $wpdb;
    $table = $wpdb->prefix . SYNCMASTER_PRODUCTS_TABLE;
    return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
}

function syncmaster_handle_add_sku() {
    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'syncmaster'));
    }

    check_admin_referer('syncmaster_add_sku');

    $sku = sanitize_text_field(wp_unslash($_POST['sku'] ?? ''));
    if ($sku !== '') {
        global $wpdb;
        $table = $wpdb->prefix . SYNCMASTER_PRODUCTS_TABLE;
        $wpdb->replace(
            $table,
            array('sku' => $sku, 'created_at' => current_time('mysql')),
            array('%s', '%s')
        );
    }

    wp_safe_redirect(admin_url('admin.php?page=syncmaster_products&added=1'));
    exit;
}

function syncmaster_handle_remove_sku() {
    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'syncmaster'));
    }

    check_admin_referer('syncmaster_remove_sku');

    $sku = sanitize_text_field(wp_unslash($_POST['sku'] ?? ''));
    if ($sku !== '') {
        global $wpdb;
        $table = $wpdb->prefix . SYNCMASTER_PRODUCTS_TABLE;
        $wpdb->delete($table, array('sku' => $sku), array('%s'));
    }

    wp_safe_redirect(admin_url('admin.php?page=syncmaster_products&removed=1'));
    exit;
}

function syncmaster_ss_search($query) {
    $query = strtolower($query);
    $results = array(
        array('name' => 'Sample Hoodie', 'sku' => 'HD-100'),
        array('name' => 'Classic Tee', 'sku' => 'TS-200'),
        array('name' => 'Canvas Tote', 'sku' => 'BG-300'),
        array('name' => 'Coffee Mug', 'sku' => 'MG-400'),
    );

    return array_values(array_filter($results, function ($item) use ($query) {
        return $query === '' || strpos(strtolower($item['name']), $query) !== false || strpos(strtolower($item['sku']), $query) !== false;
    }));
}
